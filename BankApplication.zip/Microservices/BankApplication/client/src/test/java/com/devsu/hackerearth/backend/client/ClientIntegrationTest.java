package com.devsu.hackerearth.backend.client;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

import com.devsu.hackerearth.backend.client.model.Client;
import com.devsu.hackerearth.backend.client.repository.ClientRepository;

@SpringBootTest
@Transactional
public class ClientIntegrationTest {

	@Autowired
	private ClientRepository clientRepository;

	@Test
	void testCreateAndRetrieveClient() {
		Client client = new Client();
		client.setName("Juan Perez");
		client.setDni("1234567890");
		client.setGender("M");
		client.setAge(30);
		client.setAddress("Calle 123");
		client.setPhone("555-1234");
		client.setPassword("password123");
		client.setIsActive(true);
		
		Client savedClient = clientRepository.save(client);
		
		assertNotNull(savedClient.getId());
		assertEquals("Juan Perez", savedClient.getName());
		
		Client retrievedClient = clientRepository.findById(savedClient.getId()).orElse(null);
		assertNotNull(retrievedClient);
		assertEquals("1234567890", retrievedClient.getDni());
	}
}