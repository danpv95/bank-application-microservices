package com.devsu.hackerearth.backend.client.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.devsu.hackerearth.backend.client.exception.ResourceNotFoundException;
import com.devsu.hackerearth.backend.client.model.Client;
import com.devsu.hackerearth.backend.client.model.dto.ClientDto;
import com.devsu.hackerearth.backend.client.model.dto.PartialClientDto;
import com.devsu.hackerearth.backend.client.repository.ClientRepository;

@Service
public class ClientServiceImpl implements ClientService {

	private final ClientRepository clientRepository;

	public ClientServiceImpl(ClientRepository clientRepository) {
		this.clientRepository = clientRepository;
	}

	@Override
	public List<ClientDto> getAll() {
		return clientRepository.findAll().stream()
				.map(this::mapToDto)
				.collect(Collectors.toList());
	}

	@Override
	public ClientDto getById(Long id) {
		Client client = clientRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Client not found with id: " + id));
		return mapToDto(client);
	}

	@Override
	@Transactional
	public ClientDto create(ClientDto clientDto) {
		Client client = mapToEntity(clientDto);
		Client savedClient = clientRepository.save(client);
		return mapToDto(savedClient);
	}

	@Override
	@Transactional
	public ClientDto update(ClientDto clientDto) {
		if (clientDto.getId() == null) {
			throw new IllegalArgumentException("Client ID must not be null for update");
		}

		Client existingClient = clientRepository.findById(clientDto.getId())
				.orElseThrow(() -> new ResourceNotFoundException("Client not found with id: " + clientDto.getId()));

		existingClient.setName(clientDto.getName());
		existingClient.setDni(clientDto.getDni());
		existingClient.setGender(clientDto.getGender());
		existingClient.setAge(clientDto.getAge());
		existingClient.setAddress(clientDto.getAddress());
		existingClient.setPhone(clientDto.getPhone());
		existingClient.setPassword(clientDto.getPassword());
		existingClient.setIsActive(clientDto.getIsActive());

		Client updatedClient = clientRepository.save(existingClient);
		return mapToDto(updatedClient);
	}

	@Override
	@Transactional
	public ClientDto partialUpdate(Long id, PartialClientDto partialClientDto) {
		Client existingClient = clientRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Client not found with id: " + id));

		if (partialClientDto.getName() != null) {
			existingClient.setName(partialClientDto.getName());
		}
		if (partialClientDto.getDni() != null) {
			existingClient.setDni(partialClientDto.getDni());
		}
		if (partialClientDto.getGender() != null) {
			existingClient.setGender(partialClientDto.getGender());
		}
		if (partialClientDto.getAge() != null) {
			existingClient.setAge(partialClientDto.getAge());
		}
		if (partialClientDto.getAddress() != null) {
			existingClient.setAddress(partialClientDto.getAddress());
		}
		if (partialClientDto.getPhone() != null) {
			existingClient.setPhone(partialClientDto.getPhone());
		}
		if (partialClientDto.getPassword() != null) {
			existingClient.setPassword(partialClientDto.getPassword());
		}
		if (partialClientDto.getIsActive() != null) {
			existingClient.setIsActive(partialClientDto.getIsActive());
		}

		Client updatedClient = clientRepository.save(existingClient);
		return mapToDto(updatedClient);
	}

	@Override
	@Transactional
	public void deleteById(Long id) {
		if (!clientRepository.existsById(id)) {
			throw new ResourceNotFoundException("Client not found with id: " + id);
		}
		clientRepository.deleteById(id);
	}

	private ClientDto mapToDto(Client client) {
		ClientDto dto = new ClientDto();
		dto.setId(client.getId());
		dto.setName(client.getName());
		dto.setDni(client.getDni());
		dto.setGender(client.getGender());
		dto.setAge(client.getAge());
		dto.setAddress(client.getAddress());
		dto.setPhone(client.getPhone());
		dto.setPassword(client.getPassword());
		dto.setIsActive(client.getIsActive());
		return dto;
	}

	private Client mapToEntity(ClientDto dto) {
		Client client = new Client();
		client.setName(dto.getName());
		client.setDni(dto.getDni());
		client.setGender(dto.getGender());
		client.setAge(dto.getAge());
		client.setAddress(dto.getAddress());
		client.setPhone(dto.getPhone());
		client.setPassword(dto.getPassword());
		client.setIsActive(dto.getIsActive() != null ? dto.getIsActive() : true);
		return client;
	}
}