package com.devsu.hackerearth.backend.account.model.dto;

import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PartialAccountDto {
	private String number;
	private String type;
	private BigDecimal initialAmount;
	private BigDecimal balance;
	private Boolean isActive;
	private Long clientId;
}