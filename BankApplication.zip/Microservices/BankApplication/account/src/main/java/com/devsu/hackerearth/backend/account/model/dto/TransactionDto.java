package com.devsu.hackerearth.backend.account.model.dto;

import java.math.BigDecimal;
import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TransactionDto {

	private Long id;
	private Date date;
	private String type;
	private BigDecimal amount;
	private BigDecimal balance;
	private Long accountId;
}