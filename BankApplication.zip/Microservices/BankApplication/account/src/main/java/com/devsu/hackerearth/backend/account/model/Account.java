package com.devsu.hackerearth.backend.account.model;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Entity
@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
@AllArgsConstructor
public class Account extends Base {
    
	@Column(unique = true, nullable = false)
	private String number;
	
	@Column(nullable = false)
	private String type;
	
	@Column(nullable = false)
	private BigDecimal initialAmount;
	
	@Column(nullable = false)
	private BigDecimal balance; 
	
	@Column(nullable = false)
	private Boolean isActive;

    @Column(name = "client_id", nullable = false)
    private Long clientId;
}