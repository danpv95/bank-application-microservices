package com.devsu.hackerearth.backend.account.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.devsu.hackerearth.backend.account.exception.InsufficientBalanceException;
import com.devsu.hackerearth.backend.account.exception.ResourceNotFoundException;
import com.devsu.hackerearth.backend.account.model.Account;
import com.devsu.hackerearth.backend.account.model.Transaction;
import com.devsu.hackerearth.backend.account.model.dto.BankStatementDto;
import com.devsu.hackerearth.backend.account.model.dto.TransactionDto;
import com.devsu.hackerearth.backend.account.repository.AccountRepository;
import com.devsu.hackerearth.backend.account.repository.TransactionRepository;

@Service
public class TransactionServiceImpl implements TransactionService {

	private final TransactionRepository transactionRepository;
	private final AccountRepository accountRepository;

	public TransactionServiceImpl(TransactionRepository transactionRepository, AccountRepository accountRepository) {
		this.transactionRepository = transactionRepository;
		this.accountRepository = accountRepository;
	}

    @Override
    public List<TransactionDto> getAll() {
        return transactionRepository.findAll().stream()
				.map(this::mapToDto)
				.collect(Collectors.toList());
    }

    @Override
    public TransactionDto getById(Long id) {
        Transaction transaction = transactionRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Transaction not found with id: " + id));
		return mapToDto(transaction);
    }

    @Override
    @Transactional
    public TransactionDto create(TransactionDto transactionDto) {
		
		Account account = accountRepository.findById(transactionDto.getAccountId())
				.orElseThrow(() -> new ResourceNotFoundException("Account not found with id: " + transactionDto.getAccountId()));
		
		BigDecimal currentBalance = account.getBalance();
		
		BigDecimal newBalance;
		BigDecimal amount = transactionDto.getAmount();
		
		if (amount.compareTo(BigDecimal.ZERO) < 0) {
			newBalance = currentBalance.add(amount); 
			
			if (newBalance.compareTo(BigDecimal.ZERO) < 0) {
				throw new InsufficientBalanceException("Saldo no disponible");
			}
		} else {
			newBalance = currentBalance.add(amount);
		}
		
		account.setBalance(newBalance);
		accountRepository.save(account);
		
		Transaction transaction = new Transaction();
		transaction.setDate(transactionDto.getDate() != null ? transactionDto.getDate() : new Date());
		transaction.setType(transactionDto.getType());
		transaction.setAmount(amount);
		transaction.setBalance(newBalance);
		transaction.setAccountId(transactionDto.getAccountId());
		
		Transaction savedTransaction = transactionRepository.save(transaction);
		
		return mapToDto(savedTransaction);
    }

    @Override
    public List<BankStatementDto> getAllByAccountClientIdAndDateBetween(Long clientId, Date dateTransactionStart, Date dateTransactionEnd) {
		
		List<BankStatementDto> report = new ArrayList<>();
		
		List<Account> accounts = accountRepository.findByClientId(clientId);
		
		if (accounts.isEmpty()) {
			throw new ResourceNotFoundException("No accounts found for client id: " + clientId);
		}
		
		for (Account account : accounts) {
			List<Transaction> transactions = transactionRepository.findByAccountIdAndDateBetween(
				account.getId(), dateTransactionStart, dateTransactionEnd);
			
			for (Transaction transaction : transactions) {
				BankStatementDto dto = new BankStatementDto();
				dto.setDate(transaction.getDate());
				dto.setClient("Cliente"); // Puedes mejorar esto consultando el microservicio de cliente
				dto.setAccountNumber(account.getNumber());
				dto.setAccountType(account.getType());
				dto.setInitialAmount(account.getInitialAmount());
				dto.setIsActive(account.getIsActive());
				dto.setTransactionType(transaction.getType());
				dto.setAmount(transaction.getAmount());
				dto.setBalance(transaction.getBalance());
				
				report.add(dto);
			}
		}
		
		return report;
    }

    @Override
    public TransactionDto getLastByAccountId(Long accountId) {
        List<Transaction> transactions = transactionRepository.findByAccountIdOrderByDateDesc(accountId);
		
		if (transactions.isEmpty()) {
			return null;
		}
		
		return mapToDto(transactions.get(0));
    }
    
	private TransactionDto mapToDto(Transaction transaction) {
		TransactionDto dto = new TransactionDto();
		dto.setId(transaction.getId());
		dto.setDate(transaction.getDate());
		dto.setType(transaction.getType());
		dto.setAmount(transaction.getAmount());
		dto.setBalance(transaction.getBalance());
		dto.setAccountId(transaction.getAccountId());
		return dto;
	}
}