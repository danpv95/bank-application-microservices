package com.devsu.hackerearth.backend.account.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.devsu.hackerearth.backend.account.exception.ResourceNotFoundException;
import com.devsu.hackerearth.backend.account.model.Account;
import com.devsu.hackerearth.backend.account.model.dto.AccountDto;
import com.devsu.hackerearth.backend.account.model.dto.PartialAccountDto;
import com.devsu.hackerearth.backend.account.repository.AccountRepository;

@Service
public class AccountServiceImpl implements AccountService {

	private final AccountRepository accountRepository;

	public AccountServiceImpl(AccountRepository accountRepository) {
		this.accountRepository = accountRepository;
	}

    @Override
    public List<AccountDto> getAll() {
        return accountRepository.findAll().stream()
				.map(this::mapToDto)
				.collect(Collectors.toList());
    }

    @Override
    public AccountDto getById(Long id) {
        Account account = accountRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Account not found with id: " + id));
		return mapToDto(account);
    }

    @Override
    @Transactional
    public AccountDto create(AccountDto accountDto) {
        Account account = mapToEntity(accountDto);
		// Al crear la cuenta, el balance inicial es igual al initialAmount
		account.setBalance(account.getInitialAmount());
		Account savedAccount = accountRepository.save(account);
		return mapToDto(savedAccount);
    }

    @Override
    @Transactional
    public AccountDto update(AccountDto accountDto) {
        if (accountDto.getId() == null) {
			throw new IllegalArgumentException("Account ID must not be null for update");
		}
		
		Account existingAccount = accountRepository.findById(accountDto.getId())
				.orElseThrow(() -> new ResourceNotFoundException("Account not found with id: " + accountDto.getId()));
		
		existingAccount.setNumber(accountDto.getNumber());
		existingAccount.setType(accountDto.getType());
		existingAccount.setInitialAmount(accountDto.getInitialAmount());
		existingAccount.setBalance(accountDto.getBalance());
		existingAccount.setIsActive(accountDto.getIsActive());
		existingAccount.setClientId(accountDto.getClientId());
		
		Account updatedAccount = accountRepository.save(existingAccount);
		return mapToDto(updatedAccount);
    }

    @Override
    @Transactional
    public AccountDto partialUpdate(Long id, PartialAccountDto partialAccountDto) {
        Account existingAccount = accountRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Account not found with id: " + id));
		
		if (partialAccountDto.getNumber() != null) {
			existingAccount.setNumber(partialAccountDto.getNumber());
		}
		if (partialAccountDto.getType() != null) {
			existingAccount.setType(partialAccountDto.getType());
		}
		if (partialAccountDto.getInitialAmount() != null) {
			existingAccount.setInitialAmount(partialAccountDto.getInitialAmount());
		}
		if (partialAccountDto.getBalance() != null) {
			existingAccount.setBalance(partialAccountDto.getBalance());
		}
		if (partialAccountDto.getIsActive() != null) {
			existingAccount.setIsActive(partialAccountDto.getIsActive());
		}
		if (partialAccountDto.getClientId() != null) {
			existingAccount.setClientId(partialAccountDto.getClientId());
		}
		
		Account updatedAccount = accountRepository.save(existingAccount);
		return mapToDto(updatedAccount);
    }

    @Override
    @Transactional
    public void deleteById(Long id) {
        if (!accountRepository.existsById(id)) {
			throw new ResourceNotFoundException("Account not found with id: " + id);
		}
		accountRepository.deleteById(id);
    }
    
	private AccountDto mapToDto(Account account) {
		AccountDto dto = new AccountDto();
		dto.setId(account.getId());
		dto.setNumber(account.getNumber());
		dto.setType(account.getType());
		dto.setInitialAmount(account.getInitialAmount());
		dto.setBalance(account.getBalance());
		dto.setIsActive(account.getIsActive());
		dto.setClientId(account.getClientId());
		return dto;
	}
	
	private Account mapToEntity(AccountDto dto) {
		Account account = new Account();
		account.setNumber(dto.getNumber());
		account.setType(dto.getType());
		account.setInitialAmount(dto.getInitialAmount());
		account.setBalance(dto.getBalance());
		account.setIsActive(dto.getIsActive() != null ? dto.getIsActive() : true);
		account.setClientId(dto.getClientId());
		return account;
	}
}