package com.devsu.hackerearth.backend.account;

import static org.junit.jupiter.api.Assertions.*;

import java.math.BigDecimal;
import java.util.Date;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

import com.devsu.hackerearth.backend.account.model.Account;
import com.devsu.hackerearth.backend.account.model.Transaction;
import com.devsu.hackerearth.backend.account.repository.AccountRepository;
import com.devsu.hackerearth.backend.account.repository.TransactionRepository;

@SpringBootTest
@Transactional
public class TransactionIntegrationTest {

	@Autowired
	private AccountRepository accountRepository;
	
	@Autowired
	private TransactionRepository transactionRepository;

	@Test
	void testCreateAccountAndTransaction() {
		Account account = new Account();
		account.setNumber("123456");
		account.setType("AHORROS");
		account.setInitialAmount(BigDecimal.valueOf(1000.0));
		account.setBalance(BigDecimal.valueOf(1000.0));
		account.setIsActive(true);
		account.setClientId(1L);
		
		Account savedAccount = accountRepository.save(account);
		assertNotNull(savedAccount.getId());
		
		Transaction transaction = new Transaction();
		transaction.setDate(new Date());
		transaction.setType("DEPOSITO");
		transaction.setAmount(BigDecimal.valueOf(500.0));
		transaction.setBalance(BigDecimal.valueOf(1500.0));
		transaction.setAccountId(savedAccount.getId());
		
		Transaction savedTransaction = transactionRepository.save(transaction);
		
		assertNotNull(savedTransaction.getId());
		assertEquals(BigDecimal.valueOf(500.0), savedTransaction.getAmount());
		assertEquals(savedAccount.getId(), savedTransaction.getAccountId());
	}
}